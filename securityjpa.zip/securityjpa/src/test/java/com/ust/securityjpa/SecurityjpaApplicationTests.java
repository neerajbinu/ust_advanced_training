package com.ust.securityjpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityjpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
