package com.ust.security.enums;

public enum Type {
	LIFE,
	HEALTH,
	AUTO,
	HOME

}
